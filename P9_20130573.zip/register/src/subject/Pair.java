package subject;

public class Pair{
	int time, day;
	Pair(){}
	Pair(int day, int time){ this.time = time; this.day= day; }
	public int getTime() {
		return time;
	}
	public int getDay() {
		return day;
	}
}