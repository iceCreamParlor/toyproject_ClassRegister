package subject;

public class Subject extends Pair{
	int hakjum;
	String name, code; Pair[] time;
	String preRequisite;
	Subject(){}
	Subject(int hakjum, String name, String code, Pair time[]){
		this.hakjum = hakjum; this.time= time;	this.name=name; this.code=code;
	}
	Subject(int hakjum, String name, String code, Pair time[], String preRequisite){
		this.hakjum= hakjum; this.time= time;	this.name=name; this.code=code; this.preRequisite = preRequisite;
	}
	public int getHakjum() {
		return hakjum;
	}
	public String getName() {
		return name;
	}
	public String getCode() {
		return code;
	}
	public Pair[] getSchedule() {
		return time;
	}
	public String getPreRequisite() {
		return preRequisite;
	}
}
