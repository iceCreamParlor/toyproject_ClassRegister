package subject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class SubjectInput extends Subject {
	public static void Input(ArrayList<Subject> allCourse) {
		try {
			BufferedReader br = new BufferedReader(new FileReader("subject.txt"));
			int num = Integer.parseInt( br.readLine() );
			
			for(int i=0; i< num; i++) {
				String inp = br.readLine();
				StringTokenizer tk = new StringTokenizer(inp);
				int hakjum = Integer.parseInt(tk.nextToken());
				String code = tk.nextToken();
				String name = tk.nextToken();
				int day1 = Integer.parseInt(tk.nextToken());
				int time1 =Integer.parseInt(tk.nextToken());
				int day2 = Integer.parseInt(tk.nextToken());
				int time2 = Integer.parseInt(tk.nextToken());
				String preRequisite = tk.nextToken();
				Pair[] course = new Pair[2];
				course[0] = new Pair(day1, time1);
				course[1] = new Pair(day2, time2);
				if(preRequisite.equals("x")) {
					allCourse.add(new Subject(hakjum, code, name, course));
				}
				else
					allCourse.add(new Subject(hakjum, code, name, course, preRequisite));
				
			} //���� �Է¹ޱ�
			br.close();
			
		}	catch(FileNotFoundException e) {
			System.out.println("subject.txt ������ �������� �ʽ��ϴ�.");
		}	catch(IOException e) {
			System.out.println("subject.txt �� �д� �������� ���� �߻�");
		}
	}
}
