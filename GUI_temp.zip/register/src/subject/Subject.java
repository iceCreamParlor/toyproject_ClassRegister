package subject;

import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;

interface Registerable{
	String name="default", code="default";
	String getName();
	String getCode();
}

public class Subject extends Pair implements Registerable{
	int hakjum;
	String name= "          ", code;
	Pair[] time;
	String preRequisite;
	Subject(){}
	Subject(String code, String name){
		this.code = code; this.name = name;
	}
	Subject(int hakjum, String code, String name, Pair time[]){
		this.hakjum = hakjum; this.time= time;	this.name=name; this.code=code;
	}
	Subject(int hakjum, String code, String name, Pair time[], String preRequisite){
		this.hakjum= hakjum; this.time= time;	this.name=name; this.code=code; this.preRequisite = preRequisite;
	}
	public int getHakjum() {
		return hakjum;
	}
	public String getName() {
		return name;
	}
	public String getCode() {
		return code;
	}
	public Pair[] getSchedule() {
		return time;
	}
	public String getPreRequisite() {
		return preRequisite;
	}
	public boolean equals(Subject s) {
		if(s.name == name || s.code == code)	return true;
		else return false;
	}
	public String toString(Subject s) {
		return s.getName();
	}

	public static void ViewAllSubject(ArrayList<Subject> allCourse) {
		Iterator<Subject> itr = allCourse.iterator();
		while(itr.hasNext()) {
			Subject temp = itr.next();
			System.out.println("���� : " + temp.getHakjum());
			System.out.println("����� : " + temp.getName());
			System.out.println("�����ڵ� : " + temp.getCode());
			System.out.println("���� �ð� : " + temp.getSchedule()[0].getDay()+ "  " + temp.getSchedule()[0].getTime() + " ����   /  " + temp.getSchedule()[1].getDay() + "  "+ temp.getSchedule()[1].getTime() + " ����");
			System.out.println("�������� : " + temp.getPreRequisite());
			System.out.println();
		}
	}
	public static void ViewAllPastSubject(ArrayList<Subject> pastCourse) {
		Iterator<Subject> itr = pastCourse.iterator();
		while(itr.hasNext()) {
			Subject temp = itr.next();
			System.out.println("�����ڵ� : " + temp.getCode());
			System.out.println("����� : " + temp.getName());
			System.out.println();
		}
		ViewAllPastSubjectClass vapsc = new ViewAllPastSubjectClass(pastCourse);
	}
	
}

class ViewAllPastSubjectClass extends Frame{
	ViewAllPastSubjectClass(ArrayList<Subject> pastCourse) {
		
		super("���� �������� ����");
		this.setBounds(200, 200, 500, 500);
		this.setLayout(new GridLayout(11,2));
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				ViewAllPastSubjectClass.this.setVisible(false);
				ViewAllPastSubjectClass.this.dispose();
			}
		});
		
		this.add(new Label("���� �ڵ�"+"          "+"�����"));
		Iterator<Subject> itr = pastCourse.iterator();
		while(itr.hasNext()) {
			Subject sbj = itr.next();
			this.add(new Label(sbj.getCode()+"          " + sbj.getName()));
		}
		this.setVisible(true);	
		
	}
}