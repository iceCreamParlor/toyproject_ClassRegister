package subject;

import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.util.ArrayList;
import java.util.Iterator;

interface Registerable{
	String name="default", code="default";
	String getName();
	String getCode();
}

public class Subject extends Pair implements Registerable{
	int hakjum;
	String name= "          ", code;
	Pair[] time;
	String preRequisite;
	Subject(){}
	Subject(String code, String name){
		this.code = code; this.name = name;
	}
	Subject(int hakjum, String code, String name, Pair time[]){
		this.hakjum = hakjum; this.time= time;	this.name=name; this.code=code;
	}
	Subject(int hakjum, String code, String name, Pair time[], String preRequisite){
		this.hakjum= hakjum; this.time= time;	this.name=name; this.code=code; this.preRequisite = preRequisite;
	}
	public int getHakjum() {
		return hakjum;
	}
	public String getName() {
		return name;
	}
	public String getCode() {
		return code;
	}
	public Pair[] getSchedule() {
		return time;
	}
	public String getPreRequisite() {
		return preRequisite;
	}
	public boolean equals(Subject s) {
		if(s.name == name || s.code == code)	return true;
		else return false;
	}
	public String toString(Subject s) {
		return s.getName();
	}

	public static void ViewAllSubject(ArrayList<Subject> allCourse) {
		ViewAllSubjectClass va = new ViewAllSubjectClass(allCourse);
		Iterator<Subject> itr = allCourse.iterator();
		while(itr.hasNext()) {
			Subject temp = itr.next();
			System.out.println("���� : " + temp.getHakjum());
			System.out.println("����� : " + temp.getName());
			System.out.println("�����ڵ� : " + temp.getCode());
			System.out.println("���� �ð� : " + temp.getSchedule()[0].getDay()+ "  " + temp.getSchedule()[0].getTime() + " ����   /  " + temp.getSchedule()[1].getDay() + "  "+ temp.getSchedule()[1].getTime() + " ����");
			System.out.println("�������� : " + temp.getPreRequisite());
			System.out.println();
		}
	}
	public static void ViewAllPastSubject(ArrayList<Subject> pastCourse) {
		Iterator<Subject> itr = pastCourse.iterator();
		while(itr.hasNext()) {
			Subject temp = itr.next();
			System.out.println("�����ڵ� : " + temp.getCode());
			System.out.println("����� : " + temp.getName());
			System.out.println();
		}
	}
	public static void ViewMyTimeTable(Subject[][] timeTable) {
		MyTimeTable mt = new MyTimeTable(timeTable);
	}
}
class ViewAllSubjectClass extends Frame{
	
	ViewAllSubjectClass(ArrayList<Subject> allCourse){
		super("���� ������ ����");
		this.setBounds(200, 200, 1000, 1000);
		this.setLayout(new GridLayout(11, 6));
		this.add(new Label("���� �ڵ�"));
		this.add(new Label("�����"));
		this.add(new Label("���� �ð� (1)"));
		this.add(new Label("�ð� �ð� (2)"));
		this.add(new Label("���� ����"));
		Iterator<Subject> itr = allCourse.iterator();
		while(itr.hasNext()) {
			Subject sbj = itr.next();
			this.add(new Label(sbj.getCode()));
			this.add(new Label(sbj.getName()));
			this.add(new Label(sbj.getSchedule()[0].getDay()+"����"+sbj.getSchedule()[0].getTime()+"���� "));
			this.add(new Label(sbj.getSchedule()[1].getDay()+"����"+sbj.getSchedule()[1].getTime()+"���� "));
			this.add(new Label(sbj.getPreRequisite()));
		}
		this.setVisible(true);
	}
}
class MyTimeTable extends Frame{
	Label lb[][] = new Label[9][8];
	MyTimeTable(Subject[][] timeTable){
		super("�� �ð�ǥ");
		this.setLayout(new GridLayout(9, 8));
		this.setBounds(200, 200, 900, 700);
		this.add(new Label());
		this.add(new Label("��", Label.CENTER));this.add(new Label("ȭ", Label.CENTER));this.add(new Label("��", Label.CENTER));this.add(new Label("��", Label.CENTER));this.add(new Label("��", Label.CENTER));this.add(new Label("��", Label.CENTER));this.add(new Label("��", Label.CENTER));
	
		for(int i=1; i<9; i++) {
			this.add(new Label(i+"����"));
			for(int j=1; j<8; j++) {
				if(timeTable[i][j] == null) {
					lb[i][j] = new Label(" ", Label.CENTER);
					this.add(lb[i][j]);
				}
				else {
					lb[i][j] = new Label( timeTable[i][j].getName(), Label.CENTER );
					this.add(lb[i][j]);
				}
			}
		}
		this.setVisible(true);
	}
}
